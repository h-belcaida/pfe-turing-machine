# TuringGUI - A Turing Machine Simulator User Interface
This project was completed for the final portion of CS330901 Topics In Computer Science - Computability and Complexity taught by [Howard Straubing](http://www.cs.bc.edu/~straubin/). It is a python program which can simulate the run of Turing Machines of various kinds graphically. It is based on the Turing Machine simulator used in said class. 

Created by [David Kocen](https://github.com/dkocen) and [Brian Ward](https://github.com/wardbrian)

For more information, please consult the [full manual](/Docs/User%20Manual.pdf).